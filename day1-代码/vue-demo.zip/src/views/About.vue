<template>
  <div class="about">
    <h1>This is an about page</h1>
     <!--
    <p>{{msg}}</p>
    
    <p>{{msg2}}</p>
   
    <p>{{msg3}}</p>
    <button @click="changeMsg">更改msg的值</button>
     -->
     <p>{{num}}</p>
     <p>{{doubleNum}}</p>
     <button @click="add">num++</button>
     <br/><br/>
     <!--
      <Test :msg="msg2"/>
      -->

      <Test />
  </div>
</template>

<script>
import Test from '@/components/Test'
import { reactive, toRefs , ref, computed, watch, onMounted, onUnmounted, provide } from '@vue/composition-api'
export default {
  components: {
    Test
  },
  data() {
    return {
      msg: '对不起，我是一个警察'
    }
  },

  beforeCreate() {
    // console.log('----beforeCreate------')
  },

  setup() {
    // console.log('----setup----')
    const state = reactive({
      msg2: '你是个坏蛋',
      num: 1,
      doubleNum: computed(() => state.num * 3)
    })

    watch(() => state.num,(newValue,oldValue) => {
      console.log(newValue)
      console.log(oldValue)
    })

    // return state

    const msg3 = ref('加油加油~')

    const changeMsg = () => {
      // console.log('------changeMsg-------')
      state.msg2 = '你是个大花旦'

      msg3.value = '刚把得'
    }

    const add = () => {
      state.num++
    }

    // const doubleNum = computed(() => {
    //   return state.num * 2
    // })

    onMounted(() => {
      // console.log('---onMounted----')
    })

    onUnmounted(() => {
      // console.log('---onUnmounted----')
    })

    provide('msg',"就你是个鸡蛋啊")

    // data、method、
    return {
      msg3,
      ...toRefs(state),
      changeMsg,
      add,
      // doubleNum
    }
  },

  created() {
    // console.log('-----created--------') 
  }
}
</script>
