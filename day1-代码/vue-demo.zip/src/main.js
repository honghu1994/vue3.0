import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false

// 让vue2.x的项目中可以使用vue3.x的语法
import VueCompositionAPI from '@vue/composition-api'
Vue.use(VueCompositionAPI)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
