<template>
    <div>
        子组件---{{myMsg}}
    </div>
</template>

<script>
import { reactive,inject } from '@vue/composition-api'
export default {
    // props: ['msg'],
    setup(props) {
        // console.log("子组件...",props)

        const state = reactive({
            // myMsg: props.msg
            myMsg: inject('msg')
        })

        return state
    }
}
</script>